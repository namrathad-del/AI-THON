import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

export interface SentimentAnalysis {
  rating: number;
  confidence: number;
  insights: string[];
  recommendedActions: string[];
}

export async function analyzeMoodSentiment(
  journalEntry: string,
  moodScore: number,
  emotions: string[]
): Promise<SentimentAnalysis> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a mental health sentiment analysis expert. Analyze the provided journal entry, mood score (1-10), and selected emotions to provide insights and recommendations. 

          Respond with JSON in this exact format:
          {
            "rating": number (1-10 sentiment rating),
            "confidence": number (0-1 confidence score),
            "insights": array of strings (2-3 key insights about the person's mental state),
            "recommendedActions": array of strings (2-3 specific, actionable recommendations)
          }
          
          Focus on being supportive, constructive, and specific in your recommendations.`,
        },
        {
          role: "user",
          content: `Journal Entry: "${journalEntry}"
          Mood Score: ${moodScore}/10
          Selected Emotions: ${emotions.join(", ")}`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      rating: Math.max(1, Math.min(10, Math.round(result.rating || moodScore))),
      confidence: Math.max(0, Math.min(1, result.confidence || 0.5)),
      insights: result.insights || [],
      recommendedActions: result.recommendedActions || [],
    };
  } catch (error) {
    console.error("Failed to analyze sentiment:", error);
    // Return a fallback analysis based on mood score
    return {
      rating: moodScore,
      confidence: 0.3,
      insights: ["Unable to analyze journal entry at this time."],
      recommendedActions: ["Consider trying some mindfulness exercises."],
    };
  }
}

export async function generatePersonalizedRecommendations(
  recentMoodEntries: Array<{ moodScore: number; emotions: string[]; date: Date }>,
  availableContent: Array<{ id: string; title: string; category: string; description: string }>
): Promise<Array<{ contentId: string; reason: string; confidence: number }>> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a mental health recommendation engine. Based on recent mood patterns and available wellness content, recommend the most relevant resources.

          Respond with JSON in this exact format:
          {
            "recommendations": [
              {
                "contentId": "string",
                "reason": "string (explanation of why this content is recommended)",
                "confidence": number (0-1 confidence in this recommendation)
              }
            ]
          }
          
          Recommend 3-5 most relevant pieces of content based on mood patterns and needs.`,
        },
        {
          role: "user",
          content: `Recent Mood Data: ${JSON.stringify(recentMoodEntries)}
          
          Available Content: ${JSON.stringify(availableContent)}`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.recommendations || [];
  } catch (error) {
    console.error("Failed to generate recommendations:", error);
    // Return fallback recommendations
    return availableContent.slice(0, 3).map(content => ({
      contentId: content.id,
      reason: "Recommended based on general wellness principles.",
      confidence: 0.3,
    }));
  }
}
