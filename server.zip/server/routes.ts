import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMoodEntrySchema } from "@shared/schema";
import { analyzeMoodSentiment, generatePersonalizedRecommendations } from "./openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Mood entry endpoints
  app.get("/api/mood-entries", async (req, res) => {
    try {
      // For demo purposes, using a default user ID
      const userId = "demo-user";
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const entries = await storage.getMoodEntriesByUser(userId, limit);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch mood entries" });
    }
  });

  app.get("/api/mood-entries/range", async (req, res) => {
    try {
      const userId = "demo-user";
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "Start date and end date are required" });
      }

      const entries = await storage.getMoodEntriesByUserAndDateRange(
        userId,
        new Date(startDate as string),
        new Date(endDate as string)
      );
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch mood entries for date range" });
    }
  });

  app.post("/api/mood-entries", async (req, res) => {
    try {
      const userId = "demo-user";
      const validatedData = insertMoodEntrySchema.parse(req.body);
      
      // Create the mood entry first
      const moodEntry = await storage.createMoodEntry({
        ...validatedData,
        userId,
      });

      // If there's a journal entry, analyze sentiment
      if (validatedData.journalEntry && validatedData.journalEntry.trim()) {
        try {
          const sentimentAnalysis = await analyzeMoodSentiment(
            validatedData.journalEntry,
            validatedData.moodScore,
            validatedData.emotions
          );

          // Update the mood entry with sentiment analysis
          const updatedEntry = await storage.updateMoodEntry(moodEntry.id, {
            sentimentScore: sentimentAnalysis.rating,
            sentimentConfidence: sentimentAnalysis.confidence,
          });

          res.json({ 
            moodEntry: updatedEntry, 
            sentimentAnalysis 
          });
        } catch (sentimentError) {
          console.error("Sentiment analysis failed:", sentimentError);
          // Return the mood entry even if sentiment analysis fails
          res.json({ moodEntry });
        }
      } else {
        res.json({ moodEntry });
      }
    } catch (error) {
      console.error("Failed to create mood entry:", error);
      res.status(400).json({ message: "Invalid mood entry data" });
    }
  });

  // Analytics endpoints
  app.get("/api/analytics/weekly-average", async (req, res) => {
    try {
      const userId = "demo-user";
      const endDate = new Date();
      const startDate = new Date(endDate.getTime() - (7 * 24 * 60 * 60 * 1000));
      
      const entries = await storage.getMoodEntriesByUserAndDateRange(userId, startDate, endDate);
      const average = entries.length > 0 
        ? entries.reduce((sum, entry) => sum + entry.moodScore, 0) / entries.length
        : 0;

      res.json({ average: Math.round(average * 10) / 10 });
    } catch (error) {
      res.status(500).json({ message: "Failed to calculate weekly average" });
    }
  });

  app.get("/api/analytics/streak", async (req, res) => {
    try {
      const userId = "demo-user";
      const entries = await storage.getMoodEntriesByUser(userId, 365);
      
      // Calculate streak of consecutive days with entries
      let streak = 0;
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      for (let i = 0; i < 365; i++) {
        const checkDate = new Date(today.getTime() - (i * 24 * 60 * 60 * 1000));
        const hasEntry = entries.some(entry => {
          const entryDate = new Date(entry.date);
          entryDate.setHours(0, 0, 0, 0);
          return entryDate.getTime() === checkDate.getTime();
        });

        if (hasEntry) {
          streak++;
        } else {
          break;
        }
      }

      res.json({ streak });
    } catch (error) {
      res.status(500).json({ message: "Failed to calculate streak" });
    }
  });

  app.get("/api/analytics/emotion-frequency", async (req, res) => {
    try {
      const userId = "demo-user";
      const days = parseInt(req.query.days as string) || 30;
      const endDate = new Date();
      const startDate = new Date(endDate.getTime() - (days * 24 * 60 * 60 * 1000));
      
      const entries = await storage.getMoodEntriesByUserAndDateRange(userId, startDate, endDate);
      const emotionCount: { [emotion: string]: number } = {};

      entries.forEach(entry => {
        entry.emotions.forEach(emotion => {
          emotionCount[emotion] = (emotionCount[emotion] || 0) + 1;
        });
      });

      res.json(emotionCount);
    } catch (error) {
      res.status(500).json({ message: "Failed to calculate emotion frequency" });
    }
  });

  // Wellness content endpoints
  app.get("/api/wellness-content", async (req, res) => {
    try {
      const category = req.query.category as string;
      const content = category 
        ? await storage.getWellnessContentByCategory(category)
        : await storage.getAllWellnessContent();
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch wellness content" });
    }
  });

  // Recommendations endpoints
  app.get("/api/recommendations", async (req, res) => {
    try {
      const userId = "demo-user";
      const recommendations = await storage.getRecommendationsForUser(userId);
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recommendations" });
    }
  });

  app.post("/api/recommendations/generate", async (req, res) => {
    try {
      const userId = "demo-user";
      
      // Get recent mood entries (last 14 days)
      const endDate = new Date();
      const startDate = new Date(endDate.getTime() - (14 * 24 * 60 * 60 * 1000));
      const recentEntries = await storage.getMoodEntriesByUserAndDateRange(userId, startDate, endDate);
      
      // Get available content
      const availableContent = await storage.getAllWellnessContent();
      
      // Generate recommendations using AI
      const aiRecommendations = await generatePersonalizedRecommendations(
        recentEntries.map(entry => ({
          moodScore: entry.moodScore,
          emotions: entry.emotions,
          date: entry.date,
        })),
        availableContent.map(content => ({
          id: content.id,
          title: content.title,
          category: content.category,
          description: content.description,
        }))
      );

      // Store recommendations in storage
      const storedRecommendations = await Promise.all(
        aiRecommendations.map(rec => 
          storage.createRecommendation({
            userId,
            contentId: rec.contentId,
            reason: rec.reason,
            confidence: rec.confidence,
          })
        )
      );

      res.json(storedRecommendations);
    } catch (error) {
      console.error("Failed to generate recommendations:", error);
      res.status(500).json({ message: "Failed to generate recommendations" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
