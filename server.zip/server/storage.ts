import { type User, type InsertUser, type MoodEntry, type InsertMoodEntry, type WellnessContent, type InsertWellnessContent, type Recommendation, type InsertRecommendation } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Mood entry operations
  getMoodEntry(id: string): Promise<MoodEntry | undefined>;
  getMoodEntriesByUser(userId: string, limit?: number): Promise<MoodEntry[]>;
  getMoodEntriesByUserAndDateRange(userId: string, startDate: Date, endDate: Date): Promise<MoodEntry[]>;
  createMoodEntry(entry: InsertMoodEntry & { userId: string }): Promise<MoodEntry>;
  updateMoodEntry(id: string, updates: Partial<MoodEntry>): Promise<MoodEntry | undefined>;

  // Wellness content operations
  getAllWellnessContent(): Promise<WellnessContent[]>;
  getWellnessContentByCategory(category: string): Promise<WellnessContent[]>;
  createWellnessContent(content: InsertWellnessContent): Promise<WellnessContent>;

  // Recommendation operations
  getRecommendationsForUser(userId: string): Promise<(Recommendation & { content: WellnessContent })[]>;
  createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private moodEntries: Map<string, MoodEntry>;
  private wellnessContent: Map<string, WellnessContent>;
  private recommendations: Map<string, Recommendation>;

  constructor() {
    this.users = new Map();
    this.moodEntries = new Map();
    this.wellnessContent = new Map();
    this.recommendations = new Map();
    this.initializeWellnessContent();
  }

  private initializeWellnessContent() {
    const initialContent: WellnessContent[] = [
      {
        id: randomUUID(),
        title: "5-Minute Breathing Exercise",
        description: "A simple breathing technique to help reduce stress and improve focus, perfect for managing anxiety and promoting calm.",
        category: "mindfulness",
        content: "Find a comfortable position and close your eyes. Breathe in slowly for 4 counts, hold for 4 counts, then breathe out for 6 counts. Repeat this cycle for 5 minutes.",
        imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        duration: 5,
        difficulty: "beginner",
      },
      {
        id: randomUUID(),
        title: "Gratitude Journaling",
        description: "Learn how to practice gratitude journaling to boost your mood and overall well-being.",
        category: "mindfulness",
        content: "Each day, write down three things you're grateful for. Be specific and focus on why each item brings you joy or appreciation.",
        imageUrl: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        duration: 10,
        difficulty: "beginner",
      },
      {
        id: randomUUID(),
        title: "Mindful Walking",
        description: "Discover the benefits of mindful walking and how it can improve your mental clarity and mood.",
        category: "exercise",
        content: "Take a slow, deliberate walk while focusing on each step. Notice the sensation of your feet touching the ground and the rhythm of your breathing.",
        imageUrl: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        duration: 15,
        difficulty: "beginner",
      },
      {
        id: randomUUID(),
        title: "Progressive Muscle Relaxation",
        description: "A technique to reduce physical tension and promote better sleep quality.",
        category: "sleep",
        content: "Starting from your toes, tense each muscle group for 5 seconds, then release. Work your way up through your entire body.",
        imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        duration: 20,
        difficulty: "intermediate",
      },
      {
        id: randomUUID(),
        title: "Social Connection Tips",
        description: "Strategies for maintaining meaningful relationships and building social support.",
        category: "social",
        content: "Reach out to one person each day. This could be a text, call, or in-person conversation. Focus on genuine connection rather than social media interactions.",
        imageUrl: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        duration: 30,
        difficulty: "beginner",
      },
    ];

    initialContent.forEach(content => {
      this.wellnessContent.set(content.id, content);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getMoodEntry(id: string): Promise<MoodEntry | undefined> {
    return this.moodEntries.get(id);
  }

  async getMoodEntriesByUser(userId: string, limit?: number): Promise<MoodEntry[]> {
    const entries = Array.from(this.moodEntries.values())
      .filter(entry => entry.userId === userId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    return limit ? entries.slice(0, limit) : entries;
  }

  async getMoodEntriesByUserAndDateRange(userId: string, startDate: Date, endDate: Date): Promise<MoodEntry[]> {
    return Array.from(this.moodEntries.values())
      .filter(entry => 
        entry.userId === userId &&
        new Date(entry.date) >= startDate &&
        new Date(entry.date) <= endDate
      )
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }

  async createMoodEntry(entry: InsertMoodEntry & { userId: string }): Promise<MoodEntry> {
    const id = randomUUID();
    const moodEntry: MoodEntry = {
      ...entry,
      id,
      date: new Date(),
      journalEntry: entry.journalEntry || null,
      sentimentScore: null,
      sentimentConfidence: null,
    };
    this.moodEntries.set(id, moodEntry);
    return moodEntry;
  }

  async updateMoodEntry(id: string, updates: Partial<MoodEntry>): Promise<MoodEntry | undefined> {
    const entry = this.moodEntries.get(id);
    if (!entry) return undefined;

    const updatedEntry = { ...entry, ...updates };
    this.moodEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async getAllWellnessContent(): Promise<WellnessContent[]> {
    return Array.from(this.wellnessContent.values());
  }

  async getWellnessContentByCategory(category: string): Promise<WellnessContent[]> {
    return Array.from(this.wellnessContent.values())
      .filter(content => content.category === category);
  }

  async createWellnessContent(content: InsertWellnessContent): Promise<WellnessContent> {
    const id = randomUUID();
    const wellnessContent: WellnessContent = { 
      ...content, 
      id,
      duration: content.duration || null,
      imageUrl: content.imageUrl || null,
      difficulty: content.difficulty || null
    };
    this.wellnessContent.set(id, wellnessContent);
    return wellnessContent;
  }

  async getRecommendationsForUser(userId: string): Promise<(Recommendation & { content: WellnessContent })[]> {
    const userRecommendations = Array.from(this.recommendations.values())
      .filter(rec => rec.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return userRecommendations.map(rec => {
      const content = this.wellnessContent.get(rec.contentId);
      return { ...rec, content: content! };
    }).filter(rec => rec.content);
  }

  async createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation> {
    const id = randomUUID();
    const rec: Recommendation = {
      ...recommendation,
      id,
      createdAt: new Date(),
    };
    this.recommendations.set(id, rec);
    return rec;
  }
}

export const storage = new MemStorage();
