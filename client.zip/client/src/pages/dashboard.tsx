import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Book, Leaf, TrendingUp, Flame, Brain, Bell } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/header";
import MoodCheckIn from "@/components/mood-check-in";
import TrendVisualization from "@/components/trend-visualization";
import MoodCalendar from "@/components/mood-calendar";
import WellnessLibrary from "@/components/wellness-library";
import type { MoodEntry } from "@shared/schema";

export default function Dashboard() {
  const queryClient = useQueryClient();

  // Fetch recent mood entries
  const { data: recentEntries = [] } = useQuery<MoodEntry[]>({
    queryKey: ["/api/mood-entries"],
  });

  // Fetch analytics
  const { data: weeklyAverage } = useQuery<{ average: number }>({
    queryKey: ["/api/analytics/weekly-average"],
  });

  const { data: streak } = useQuery<{ streak: number }>({
    queryKey: ["/api/analytics/streak"],
  });

  // Generate recommendations
  const generateRecommendations = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/recommendations/generate", {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recommendations"] });
    },
  });

  // Get current mood data
  const currentMood = recentEntries.length > 0 ? recentEntries[0] : null;
  const currentDate = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  const getMoodLabel = (score: number): string => {
    if (score >= 8) return "Excellent";
    if (score >= 6) return "Good";
    if (score >= 4) return "Okay";
    return "Low";
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Overview */}
        <section id="dashboard" className="mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Current Status Card */}
            <div className="lg:col-span-2">
              <Card className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-semibold text-foreground">Today's Overview</h2>
                  <span className="text-sm text-muted-foreground" data-testid="text-current-date">
                    {currentDate}
                  </span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="w-20 h-20 mx-auto bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mb-3">
                      <span className="text-2xl font-bold text-white" data-testid="text-current-mood-score">
                        {currentMood?.moodScore || "—"}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">Current Mood</p>
                    <p className="font-medium text-foreground" data-testid="text-current-mood-label">
                      {currentMood ? getMoodLabel(currentMood.moodScore) : "No data"}
                    </p>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-20 h-20 mx-auto bg-gradient-to-br from-secondary to-accent rounded-full flex items-center justify-center mb-3">
                      <TrendingUp className="text-xl text-white" />
                    </div>
                    <p className="text-sm text-muted-foreground">7-Day Average</p>
                    <p className="font-medium text-foreground" data-testid="text-weekly-average">
                      {weeklyAverage?.average?.toFixed(1) || "—"}
                    </p>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-20 h-20 mx-auto bg-gradient-to-br from-accent to-primary rounded-full flex items-center justify-center mb-3">
                      <Flame className="text-xl text-white" />
                    </div>
                    <p className="text-sm text-muted-foreground">Check-in Streak</p>
                    <p className="font-medium text-foreground" data-testid="text-checkin-streak">
                      {streak?.streak || 0} days
                    </p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Quick Actions */}
            <div className="space-y-4">
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Button 
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                    onClick={() => document.getElementById('check-in')?.scrollIntoView({ behavior: 'smooth' })}
                    data-testid="button-daily-checkin"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Daily Check-in
                  </Button>
                  <Button 
                    variant="secondary"
                    className="w-full"
                    onClick={() => document.getElementById('check-in')?.scrollIntoView({ behavior: 'smooth' })}
                    data-testid="button-journal-entry"
                  >
                    <Book className="mr-2 h-4 w-4" />
                    Journal Entry
                  </Button>
                  <Button 
                    variant="outline"
                    className="w-full"
                    onClick={() => document.getElementById('wellness')?.scrollIntoView({ behavior: 'smooth' })}
                    data-testid="button-mindfulness"
                  >
                    <Leaf className="mr-2 h-4 w-4" />
                    Mindfulness
                  </Button>
                </div>
              </Card>

              {/* Today's Recommendation */}
              <Card className="bg-gradient-to-br from-accent to-primary p-6 text-white">
                <h3 className="text-lg font-semibold mb-2">Today's Recommendation</h3>
                <p className="text-sm opacity-90 mb-4" data-testid="text-daily-recommendation">
                  {recentEntries.length > 0 
                    ? "Based on your recent mood patterns, try a 5-minute breathing exercise to help maintain your positive momentum."
                    : "Start your mental health journey with a daily mood check-in to track your well-being."
                  }
                </p>
                <Button 
                  variant="ghost"
                  className="bg-white/20 hover:bg-white/30 text-white"
                  onClick={() => generateRecommendations.mutate()}
                  disabled={generateRecommendations.isPending}
                  data-testid="button-try-recommendation"
                >
                  {generateRecommendations.isPending ? "Generating..." : "Try It Now"}
                </Button>
              </Card>
            </div>
          </div>
        </section>

        {/* Components */}
        <MoodCheckIn />
        <TrendVisualization />
        <MoodCalendar />
        <WellnessLibrary />
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Brain className="text-primary text-xl" />
                <span className="font-bold text-foreground">MindFlow</span>
              </div>
              <p className="text-sm text-muted-foreground">Your personal mental health companion, helping you track, understand, and improve your well-being.</p>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-3">Features</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Mood Tracking</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">AI Insights</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Wellness Library</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Progress Reports</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-3">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Contact Us</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-3">Emergency Resources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors text-destructive">Crisis Hotline</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Find a Therapist</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Mental Health Resources</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border pt-6 mt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2023 MindFlow. All rights reserved. | Mental health tracking and insights platform.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
