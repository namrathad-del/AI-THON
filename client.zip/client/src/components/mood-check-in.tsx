import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Shield, Check } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { InsertMoodEntry } from "@shared/schema";

const EMOTIONS = [
  { id: "happy", label: "😊 Happy", color: "bg-secondary text-secondary-foreground" },
  { id: "anxious", label: "😰 Anxious", color: "bg-chart-4 text-white" },
  { id: "tired", label: "😴 Tired", color: "bg-muted text-muted-foreground" },
  { id: "motivated", label: "💪 Motivated", color: "bg-accent text-accent-foreground" },
  { id: "sad", label: "😢 Sad", color: "bg-chart-2 text-white" },
  { id: "angry", label: "😡 Angry", color: "bg-destructive text-destructive-foreground" },
  { id: "grateful", label: "🤗 Grateful", color: "bg-primary text-primary-foreground" },
  { id: "calm", label: "😌 Calm", color: "bg-secondary text-secondary-foreground" },
  { id: "stressed", label: "😕 Stressed", color: "bg-chart-4 text-white" },
  { id: "excited", label: "🎉 Excited", color: "bg-accent text-accent-foreground" },
];

export default function MoodCheckIn() {
  const [selectedMood, setSelectedMood] = useState<number>(7);
  const [selectedEmotions, setSelectedEmotions] = useState<string[]>(["happy", "motivated"]);
  const [journalEntry, setJournalEntry] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createMoodEntry = useMutation({
    mutationFn: async (data: InsertMoodEntry) => {
      const response = await apiRequest("POST", "/api/mood-entries", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Check-in Complete! ✨",
        description: "Your mood has been recorded successfully.",
      });
      
      // Reset form
      setSelectedMood(7);
      setSelectedEmotions([]);
      setJournalEntry("");
      
      // Invalidate and refetch mood entries
      queryClient.invalidateQueries({ queryKey: ["/api/mood-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      
      // If sentiment analysis was performed, show insights
      if (data.sentimentAnalysis) {
        setTimeout(() => {
          toast({
            title: "AI Insights Generated",
            description: data.sentimentAnalysis.insights[0] || "Your journal entry has been analyzed for personalized insights.",
          });
        }, 1500);
      }
    },
    onError: (error) => {
      toast({
        title: "Check-in Failed",
        description: "There was an error saving your mood entry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleMoodSelect = (mood: number) => {
    setSelectedMood(mood);
  };

  const toggleEmotion = (emotionId: string) => {
    setSelectedEmotions(prev => 
      prev.includes(emotionId) 
        ? prev.filter(id => id !== emotionId)
        : [...prev, emotionId]
    );
  };

  const handleSubmit = () => {
    createMoodEntry.mutate({
      moodScore: selectedMood,
      emotions: selectedEmotions,
      journalEntry: journalEntry.trim() || undefined,
    });
  };

  return (
    <section id="check-in" className="mb-12">
      <Card className="p-8">
        <CardContent className="max-w-4xl mx-auto p-0">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-semibold text-foreground mb-2">How are you feeling today?</h2>
            <p className="text-muted-foreground">Rate your mood on a scale of 1-10 and select emotions that resonate with you</p>
          </div>

          {/* Mood Scale */}
          <div className="mb-8">
            <h3 className="text-lg font-medium text-foreground mb-4 text-center">Mood Scale</h3>
            <div className="flex justify-center items-center space-x-2 md:space-x-4">
              {Array.from({ length: 10 }, (_, i) => i + 1).map((num) => (
                <Button
                  key={num}
                  variant={selectedMood === num ? "default" : "outline"}
                  className={`mood-scale-item w-12 h-12 md:w-14 md:h-14 rounded-full font-semibold ${
                    selectedMood === num ? "selected" : ""
                  }`}
                  onClick={() => handleMoodSelect(num)}
                  data-testid={`mood-button-${num}`}
                >
                  {num}
                </Button>
              ))}
            </div>
            <div className="flex justify-between text-sm text-muted-foreground mt-2 px-2">
              <span>Very Low</span>
              <span>Excellent</span>
            </div>
          </div>

          {/* Emotion Selection */}
          <div className="mb-8">
            <h3 className="text-lg font-medium text-foreground mb-4 text-center">Select Your Emotions</h3>
            <div className="flex flex-wrap justify-center gap-3">
              {EMOTIONS.map((emotion) => (
                <Button
                  key={emotion.id}
                  variant="outline"
                  className={`emotion-chip px-4 py-2 rounded-full text-sm font-medium ${
                    selectedEmotions.includes(emotion.id) 
                      ? `selected ${emotion.color}` 
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                  onClick={() => toggleEmotion(emotion.id)}
                  data-testid={`emotion-${emotion.id}`}
                >
                  {emotion.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Journal Entry */}
          <div className="mb-8">
            <h3 className="text-lg font-medium text-foreground mb-4">Optional Journal Entry</h3>
            <Textarea
              value={journalEntry}
              onChange={(e) => setJournalEntry(e.target.value)}
              className="w-full h-32 p-4 border border-border rounded-lg bg-input text-foreground placeholder:text-muted-foreground resize-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all"
              placeholder="Share what's on your mind today... (This will be analyzed for insights)"
              data-testid="textarea-journal"
            />
            <p className="text-xs text-muted-foreground mt-2">
              <Shield className="inline w-3 h-3 mr-1" />
              Your entries are private and analyzed using AI to provide personalized insights.
            </p>
          </div>

          {/* Submit Button */}
          <div className="text-center">
            <Button 
              onClick={handleSubmit}
              disabled={createMoodEntry.isPending}
              className="bg-primary text-primary-foreground px-8 py-3 rounded-lg font-medium hover:bg-primary/90 transition-colors flex items-center space-x-2 mx-auto"
              data-testid="button-submit-checkin"
            >
              {createMoodEntry.isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Complete Check-in</span>
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
