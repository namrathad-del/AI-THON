import { useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Brain, TrendingUp } from "lucide-react";
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

interface MoodEntry {
  id: string;
  moodScore: number;
  date: string;
  emotions: string[];
}

export default function TrendVisualization() {
  const moodChartRef = useRef<HTMLCanvasElement>(null);
  const emotionChartRef = useRef<HTMLCanvasElement>(null);
  const moodChartInstance = useRef<Chart | null>(null);
  const emotionChartInstance = useRef<Chart | null>(null);

  const { data: moodEntries = [] } = useQuery<MoodEntry[]>({
    queryKey: ["/api/mood-entries"],
  });

  const { data: emotionFrequency = {} } = useQuery<Record<string, number>>({
    queryKey: ["/api/analytics/emotion-frequency"],
  });

  // Initialize mood trend chart
  useEffect(() => {
    if (moodChartRef.current && moodEntries.length > 0) {
      const ctx = moodChartRef.current.getContext('2d');
      if (!ctx) return;

      // Destroy existing chart
      if (moodChartInstance.current) {
        moodChartInstance.current.destroy();
      }

      const last7Entries = moodEntries.slice(0, 7).reverse();
      const labels = last7Entries.map(entry => 
        new Date(entry.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      );
      const data = last7Entries.map(entry => entry.moodScore);

      moodChartInstance.current = new Chart(ctx, {
        type: 'line',
        data: {
          labels,
          datasets: [{
            label: 'Mood Score',
            data,
            borderColor: 'hsl(186, 85%, 35%)',
            backgroundColor: 'hsla(186, 85%, 35%, 0.1)',
            tension: 0.4,
            fill: true,
            pointBackgroundColor: 'hsl(186, 85%, 35%)',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 5
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              max: 10,
              grid: {
                color: 'hsl(210, 20%, 88%)'
              }
            },
            x: {
              grid: {
                color: 'hsl(210, 20%, 88%)'
              }
            }
          }
        }
      });
    }
  }, [moodEntries]);

  // Initialize emotion frequency chart
  useEffect(() => {
    if (emotionChartRef.current && Object.keys(emotionFrequency).length > 0) {
      const ctx = emotionChartRef.current.getContext('2d');
      if (!ctx) return;

      // Destroy existing chart
      if (emotionChartInstance.current) {
        emotionChartInstance.current.destroy();
      }

      const emotions = Object.keys(emotionFrequency);
      const counts = Object.values(emotionFrequency);
      const colors = [
        'hsl(186, 85%, 35%)',
        'hsl(135, 25%, 65%)',
        'hsl(14, 90%, 70%)',
        'hsl(280, 65%, 60%)',
        'hsl(45, 85%, 60%)',
      ];

      emotionChartInstance.current = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: emotions,
          datasets: [{
            data: counts as number[],
            backgroundColor: colors.slice(0, emotions.length),
            borderWidth: 0
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                usePointStyle: true,
                padding: 20
              }
            }
          }
        }
      });
    }
  }, [emotionFrequency]);

  // Calculate weekly patterns
  const weeklyPatterns = moodEntries.reduce((acc, entry) => {
    const day = new Date(entry.date).getDay();
    const dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][day];
    
    if (!acc[dayName]) {
      acc[dayName] = { total: 0, count: 0 };
    }
    acc[dayName].total += entry.moodScore;
    acc[dayName].count += 1;
    
    return acc;
  }, {} as Record<string, { total: number; count: number }>);

  const weeklyAverages = Object.entries(weeklyPatterns).map(([day, data]) => ({
    day,
    average: data.count > 0 ? data.total / data.count : 0,
    percentage: data.count > 0 ? (data.total / data.count) * 10 : 0,
  }));

  return (
    <section id="trends" className="mb-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Mood Trend Chart */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-foreground">Mood Trends</h3>
            <Select defaultValue="7days">
              <SelectTrigger className="w-32" data-testid="select-trend-period">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7days">Last 7 days</SelectItem>
                <SelectItem value="30days">Last 30 days</SelectItem>
                <SelectItem value="90days">Last 90 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="h-64 flex items-center justify-center">
            <canvas ref={moodChartRef} className="w-full h-full" data-testid="chart-mood-trends" />
          </div>
        </Card>

        {/* Emotion Frequency */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold text-foreground mb-6">Emotion Frequency</h3>
          <div className="h-64 flex items-center justify-center">
            <canvas ref={emotionChartRef} className="w-full h-full" data-testid="chart-emotion-frequency" />
          </div>
        </Card>

        {/* Weekly Pattern Analysis */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold text-foreground mb-6">Weekly Patterns</h3>
          <div className="space-y-4">
            {weeklyAverages.map(({ day, average, percentage }) => (
              <div key={day} className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground w-20">{day}</span>
                <div className="flex-1 mx-4 bg-muted rounded-full h-2 overflow-hidden">
                  <div 
                    className="bg-primary h-full rounded-full transition-all duration-500" 
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <span className="text-sm text-muted-foreground w-8" data-testid={`average-${day.toLowerCase()}`}>
                  {average.toFixed(1)}
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* AI Insights */}
        <Card className="bg-gradient-to-br from-secondary to-accent p-6 text-white">
          <h3 className="text-lg font-semibold mb-4">
            <Brain className="inline mr-2" />
            AI Insights
          </h3>
          <div className="space-y-3 text-sm">
            {moodEntries.length > 0 ? (
              <>
                <div className="bg-white/10 rounded-lg p-3">
                  <p className="font-medium mb-1">Pattern Detected</p>
                  <p className="opacity-90">
                    {weeklyAverages.find(w => w.average === Math.min(...weeklyAverages.map(w => w.average)))?.day && 
                    `Your mood tends to be lower on ${weeklyAverages.find(w => w.average === Math.min(...weeklyAverages.map(w => w.average)))?.day}s. Consider scheduling enjoyable activities to boost your mood.`}
                  </p>
                </div>
                <div className="bg-white/10 rounded-lg p-3">
                  <p className="font-medium mb-1">Positive Trend</p>
                  <p className="opacity-90">
                    {moodEntries.length >= 7 && 
                    `Your recent mood average is ${(moodEntries.slice(0, 7).reduce((sum, entry) => sum + entry.moodScore, 0) / 7).toFixed(1)}. Keep up the great work!`}
                  </p>
                </div>
                <div className="bg-white/10 rounded-lg p-3">
                  <p className="font-medium mb-1">Most Common Emotion</p>
                  <p className="opacity-90">
                    {Object.keys(emotionFrequency).length > 0 && 
                    `Your most frequent emotion this month is "${Object.entries(emotionFrequency).sort(([,a], [,b]) => (b as number) - (a as number))[0]?.[0]}". This suggests a generally positive outlook.`}
                  </p>
                </div>
              </>
            ) : (
              <div className="bg-white/10 rounded-lg p-3">
                <p className="font-medium mb-1">Start Your Journey</p>
                <p className="opacity-90">Complete a few mood check-ins to see personalized insights and patterns.</p>
              </div>
            )}
          </div>
        </Card>
      </div>
    </section>
  );
}
