import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface MoodEntry {
  id: string;
  moodScore: number;
  date: string;
  emotions: string[];
}

const getMoodColor = (score: number): string => {
  if (score >= 8) return "bg-chart-3"; // Great (orange)
  if (score >= 6) return "bg-chart-1"; // Good (teal)
  if (score >= 4) return "bg-chart-2"; // Okay (green)
  return "bg-chart-4"; // Low (purple)
};

const getMoodLabel = (score: number): string => {
  if (score >= 8) return "Great";
  if (score >= 6) return "Good";
  if (score >= 4) return "Okay";
  return "Low";
};

export default function MoodCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());

  const { data: moodEntries = [] } = useQuery<MoodEntry[]>({
    queryKey: ["/api/mood-entries"],
  });

  // Get first day of month and days in month
  const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
  const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startingDayOfWeek = firstDay.getDay();

  // Generate calendar days
  const calendarDays = [];
  
  // Empty cells for days before month starts
  for (let i = 0; i < startingDayOfWeek; i++) {
    calendarDays.push(null);
  }
  
  // Days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    const moodEntry = moodEntries.find(entry => {
      const entryDate = new Date(entry.date);
      return entryDate.toDateString() === date.toDateString();
    });
    
    calendarDays.push({
      day,
      date,
      moodEntry,
      isToday: date.toDateString() === new Date().toDateString(),
      isFuture: date > new Date(),
    });
  }

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const monthName = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <section className="mb-12">
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-foreground">Mood Calendar</h3>
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigateMonth('prev')}
              data-testid="button-prev-month"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="font-medium text-foreground min-w-[140px] text-center" data-testid="text-current-month">
              {monthName}
            </span>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => navigateMonth('next')}
              data-testid="button-next-month"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2 mb-4">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="text-center text-sm font-medium text-muted-foreground py-2">
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-2">
          {calendarDays.map((dayData, index) => {
            if (!dayData) {
              return <div key={index} className="calendar-day h-12" />;
            }

            const { day, date, moodEntry, isToday, isFuture } = dayData;

            if (isFuture) {
              return (
                <div
                  key={day}
                  className="calendar-day h-12 bg-muted rounded-lg flex items-center justify-center text-muted-foreground text-sm font-medium"
                  data-testid={`calendar-day-${day}`}
                >
                  {day}
                </div>
              );
            }

            if (moodEntry) {
              const moodColor = getMoodColor(moodEntry.moodScore);
              const moodLabel = getMoodLabel(moodEntry.moodScore);
              
              return (
                <div
                  key={day}
                  className={`calendar-day h-12 ${moodColor} rounded-lg flex items-center justify-center text-white text-sm font-medium cursor-pointer ${
                    isToday ? 'border-2 border-accent' : ''
                  }`}
                  title={`Mood: ${moodEntry.moodScore} - ${moodLabel}${moodEntry.emotions.length > 0 ? `, ${moodEntry.emotions.join(', ')}` : ''}`}
                  data-testid={`calendar-day-${day}-mood-${moodEntry.moodScore}`}
                >
                  {day}
                </div>
              );
            }

            return (
              <div
                key={day}
                className={`calendar-day h-12 bg-muted/50 rounded-lg flex items-center justify-center text-muted-foreground text-sm font-medium ${
                  isToday ? 'border-2 border-primary bg-primary text-primary-foreground' : ''
                }`}
                data-testid={`calendar-day-${day}-empty`}
              >
                {day}
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-center space-x-6 mt-6 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-chart-1 rounded" />
            <span className="text-muted-foreground">Good (6-7)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-chart-2 rounded" />
            <span className="text-muted-foreground">Okay (4-5)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-chart-3 rounded" />
            <span className="text-muted-foreground">Great (8-10)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-chart-4 rounded" />
            <span className="text-muted-foreground">Low (1-3)</span>
          </div>
        </div>
      </Card>
    </section>
  );
}
