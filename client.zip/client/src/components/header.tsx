import { Brain, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Header() {
  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Brain className="text-primary text-2xl" />
              <h1 className="text-xl font-bold text-foreground">MindFlow</h1>
            </div>
          </div>
          <nav className="hidden md:flex space-x-8">
            <a 
              href="#dashboard" 
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-dashboard"
            >
              Dashboard
            </a>
            <a 
              href="#check-in" 
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-check-in"
            >
              Check-in
            </a>
            <a 
              href="#trends" 
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-trends"
            >
              Trends
            </a>
            <a 
              href="#wellness" 
              className="text-foreground hover:text-primary transition-colors"
              data-testid="nav-wellness"
            >
              Wellness
            </a>
          </nav>
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-muted-foreground hover:text-foreground"
              data-testid="button-notifications"
            >
              <Bell className="h-5 w-5" />
            </Button>
            <div 
              className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-medium"
              data-testid="avatar-user"
            >
              <span>JD</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
