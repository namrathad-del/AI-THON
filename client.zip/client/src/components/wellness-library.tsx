import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Brain, Activity, Moon, Users } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { WellnessContent } from "@shared/schema";

const CATEGORY_ICONS = {
  mindfulness: Brain,
  exercise: Activity,
  sleep: Moon,
  social: Users,
};

const CATEGORY_COLORS = {
  mindfulness: "bg-primary/10 text-primary",
  exercise: "bg-secondary/10 text-secondary",
  sleep: "bg-accent/10 text-accent",
  social: "bg-chart-4/10 text-chart-4",
};

export default function WellnessLibrary() {
  const { data: allContent = [] } = useQuery<WellnessContent[]>({
    queryKey: ["/api/wellness-content"],
  });

  const { data: recommendations = [] } = useQuery<Array<{ content: WellnessContent; reason: string; confidence: number }>>({
    queryKey: ["/api/recommendations"],
  });

  // Get recommended content
  const recommendedContent = recommendations
    .slice(0, 3)
    .map((rec: any) => rec.content)
    .filter(Boolean);

  // If no personalized recommendations, show first 3 items
  const displayContent = recommendedContent.length > 0 ? recommendedContent : allContent.slice(0, 3);

  // Group content by category for category view
  const contentByCategory = allContent.reduce((acc, content) => {
    if (!acc[content.category]) {
      acc[content.category] = [];
    }
    acc[content.category].push(content);
    return acc;
  }, {} as Record<string, WellnessContent[]>);

  const categories = Object.entries(contentByCategory).map(([category, items]) => ({
    name: category,
    count: items.length,
    icon: CATEGORY_ICONS[category as keyof typeof CATEGORY_ICONS] || Brain,
    color: CATEGORY_COLORS[category as keyof typeof CATEGORY_COLORS] || "bg-primary/10 text-primary",
  }));

  return (
    <section id="wellness" className="mb-12">
      <div className="mb-8">
        <h2 className="text-2xl font-semibold text-foreground mb-2">Wellness Library</h2>
        <p className="text-muted-foreground">Personalized resources and coping strategies based on your mood patterns</p>
      </div>

      {/* Personalized Recommendations */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-foreground mb-4">
          {recommendedContent.length > 0 ? "Recommended for You" : "Featured Content"}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayContent.map((content: WellnessContent, index: number) => (
            <Card key={content.id} className="wellness-card overflow-hidden">
              <img 
                src={content.imageUrl || "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200"} 
                alt={content.title}
                className="w-full h-48 object-cover"
                data-testid={`img-content-${index}`}
              />
              <CardContent className="p-6">
                <div className="flex items-center space-x-2 mb-3">
                  {index === 0 && recommendedContent.length > 0 && (
                    <Badge variant="default" data-testid="badge-recommended">
                      Recommended
                    </Badge>
                  )}
                  {index === 1 && (
                    <Badge variant="secondary" data-testid="badge-trending">
                      Trending
                    </Badge>
                  )}
                  {index === 2 && (
                    <Badge className="bg-accent text-accent-foreground" data-testid="badge-popular">
                      Popular
                    </Badge>
                  )}
                  <span className="text-sm text-muted-foreground">
                    {content.duration} min read
                  </span>
                </div>
                <h4 className="font-semibold text-foreground mb-2" data-testid={`text-title-${index}`}>
                  {content.title}
                </h4>
                <p className="text-sm text-muted-foreground mb-4" data-testid={`text-description-${index}`}>
                  {content.description}
                </p>
                <Button 
                  variant="ghost" 
                  className="text-primary hover:text-primary/80 text-sm font-medium p-0 h-auto"
                  data-testid={`button-start-${index}`}
                >
                  {content.category === 'mindfulness' ? 'Start Exercise' :
                   content.category === 'exercise' ? 'Get Started' :
                   content.category === 'sleep' ? 'Try Tonight' : 'Learn More'}
                  <ArrowRight className="ml-1 h-3 w-3" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Browse by Category</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categories.map((category) => {
            const IconComponent = category.icon;
            return (
              <Card 
                key={category.name}
                className="p-6 text-center hover:bg-muted/50 transition-colors cursor-pointer"
                data-testid={`card-category-${category.name}`}
              >
                <div className={`w-12 h-12 ${category.color} rounded-full flex items-center justify-center mx-auto mb-3`}>
                  <IconComponent className="text-xl" />
                </div>
                <h4 className="font-medium text-foreground mb-1 capitalize">
                  {category.name}
                </h4>
                <p className="text-xs text-muted-foreground" data-testid={`text-count-${category.name}`}>
                  {category.count} resource{category.count !== 1 ? 's' : ''}
                </p>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
