import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, json, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const moodEntries = pgTable("mood_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull().defaultNow(),
  moodScore: integer("mood_score").notNull(), // 1-10 scale
  emotions: json("emotions").$type<string[]>().notNull().default([]),
  journalEntry: text("journal_entry"),
  sentimentScore: real("sentiment_score"), // AI-generated sentiment score
  sentimentConfidence: real("sentiment_confidence"), // Confidence in sentiment analysis
});

export const wellnessContent = pgTable("wellness_content", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // mindfulness, exercise, sleep, social
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  duration: integer("duration"), // in minutes
  difficulty: text("difficulty"), // beginner, intermediate, advanced
});

export const recommendations = pgTable("recommendations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  contentId: varchar("content_id").notNull().references(() => wellnessContent.id),
  reason: text("reason").notNull(),
  confidence: real("confidence").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).omit({
  id: true,
  userId: true,
  date: true,
  sentimentScore: true,
  sentimentConfidence: true,
}).extend({
  moodScore: z.number().min(1).max(10),
  emotions: z.array(z.string()),
  journalEntry: z.string().optional(),
});

export const insertWellnessContentSchema = createInsertSchema(wellnessContent).omit({
  id: true,
});

export const insertRecommendationSchema = createInsertSchema(recommendations).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;
export type WellnessContent = typeof wellnessContent.$inferSelect;
export type InsertWellnessContent = z.infer<typeof insertWellnessContentSchema>;
export type Recommendation = typeof recommendations.$inferSelect;
export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;
